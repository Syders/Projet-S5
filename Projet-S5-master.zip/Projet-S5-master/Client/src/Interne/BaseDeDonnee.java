package Interne;

import java.util.LinkedList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class BaseDeDonnee {
    private Connect connect = new Connect();
    private int nbFilsDiscussion;
    private Personne user;
    private List <GroupePersonne> groupes = new LinkedList<> ();
    private List <Ticket> tickets = new LinkedList<> ();
    
    private GroupePersonne groupe (String nomGroupe) {
        GroupePersonne groupe = new GroupePersonne(nomGroupe, new HashSet<> ());
        groupes.add(groupe);
        List <String> listpersonnes = connect.appartientListPersonne(nomGroupe);
        for (String listpersonne : listpersonnes) {
            Set<Personne> liste = groupe.getListePersonne();
            liste.add(personne(listpersonne));
            groupe.setListePersonne(liste);
        }
        return groupe;
    }
    
    private Personne personne (String idUtilisateur) {
        return new Personne(connect.utilisateurNom(idUtilisateur), connect.utilisateurPrenom(idUtilisateur), idUtilisateur);
    }
    
    private Ticket ticket (int noTicket) {
        Ticket ticket = new Ticket(noTicket, connect.filDiscussionTitre(noTicket), user, groupe(connect.filDiscussionNomGroupe(noTicket)), new LinkedList<>());
        if (!tickets.contains(ticket))
            tickets.add(ticket);
        List <String> listmessages = connect.filDiscussionMessage(noTicket);
        for (String listmessage : listmessages) {
            List<Message> liste = ticket.getMessage();
            liste.add(new Message(Integer.parseInt(listmessage), connect.messageTexte(Integer.parseInt(listmessage)), personne(connect.messageIdUtilisateur(Integer.parseInt(listmessage)))));
            ticket.setMessage(liste);
        }
        return ticket;
    }
    
    public Ticket tick (String titre) {
        boolean trouve = false;
        int i = 0;
        while (!trouve && i < tickets.size()) {
            if (tickets.get(i).getTitre().equals(titre))
                return tickets.get(i);
            else
                i++;
        }
        return null;
    }
    
    public Personne getUser() {
        return user;
    }

    public int getNbFilsDiscussion() {
        return nbFilsDiscussion;
    }

    public List <GroupePersonne> getGroupes() {
        return groupes;
    }

    public List <Ticket> getTickets() {
        return tickets;
    }
    
    public List <String> nomsTickets() {
        List <String> list = new LinkedList<>();
        for (Ticket ticket : tickets) {
            list.add(ticket.getTitre());
        }
        return list;
    }

    public void update (String idUtilisateur) {
        nbFilsDiscussion = connect.nbFilsDiscussion();
        if (idUtilisateur != "") {
            tickets = new LinkedList<> ();
            user = personne(idUtilisateur);
            List <String> listgroupes = connect.appartientListGroupe(idUtilisateur);
            for (String listgroupe : listgroupes) {
                GroupePersonne groupe = groupe(listgroupe);
                groupes.add(groupe);
            }
            List <String> listeInts = connect.utilisateurFilDiscussion(idUtilisateur);
            for (String listeInt : listeInts) {
                Ticket ticket = ticket(Integer.parseInt(listeInt));
                if (!tickets.contains(ticket))
                    tickets.add(ticket);
            }
            for (int i = 0; i < groupes.size(); i++) {
                List <String> listes = connect.groupeFilDiscussion(groupes.get(i).getNomGroupe());
                for (String liste : listes) {
                    Ticket ticket = ticket(Integer.parseInt(liste));
                    if (!tickets.contains(ticket))
                        tickets.add(ticket);
                }
            }
        } else {
            List <String> listgroupes = connect.groupeNomsGroupe();
            for (String listgroupe : listgroupes) {
                GroupePersonne groupe = groupe(listgroupe);
                groupes.add(groupe);
            }
        }
    }
}
