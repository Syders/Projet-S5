package Interne;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author steven
 */
public class Ticket {

    private Integer noTicket;
    private String titre;
    private Personne createur;
    private GroupePersonne groupeDestine;
    private List<Message> message;

    public Ticket(Integer noTicket, String titre, Personne createur,  GroupePersonne groupeDestine, List<Message> message) {
        this.noTicket = noTicket;
        this.titre = titre;
        this.createur = createur;
        this.groupeDestine = groupeDestine;
        this.message = message;
    }
    
    public int getNoTicket() {
        return noTicket;
    }
    
    public String getTitre() {
        return titre;
    }
    
    public List<Message> getMessage() {
        return message;
    }
    
    public List <String> messages() {
        List <String> list = new LinkedList<>();
        for (Message messag : message) {
            list.add(messag.afficherMessage());
        }
        return list;
    }
    
    public void setMessage(List<Message> message) {
        this.message = message;
    }
    
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 17 * hash + Objects.hashCode(this.noTicket);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Ticket other = (Ticket) obj;
        if (!Objects.equals(this.noTicket, other.noTicket)) {
            return false;
        }
        return true;
    }

}
