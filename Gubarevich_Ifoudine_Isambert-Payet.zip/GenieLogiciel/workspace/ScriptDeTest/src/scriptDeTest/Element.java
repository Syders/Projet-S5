package scriptDeTest;

public class Element {
	private int info;
	private Element suiv;
	
	public Element(int info, Element suiv) {
		this.info = info;
		this.suiv = suiv;
	}

	public int getInfo() {
		return info;
	}

	/*public void setInfo(int info) {
		this.info = info;
	}*/

	public Element getSuiv() {
		return suiv;
	}

	public void setSuiv(Element suiv) {
		this.suiv = suiv;
	}
}
