package scriptDeTest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ScriptDeTest {

	public static Element insere(int x, Element L) {
		Element courant, precedent, nouveau;
		boolean continuer;
		courant = L;
		precedent = null;
		continuer = (courant != null);
		while (continuer && courant != null)
			if (courant.getInfo() >= x)
				continuer = false;
			else {
				precedent = courant;
				courant = courant.getSuiv();
			}
		nouveau = new Element(x, courant);
		if (precedent == null)
			L = nouveau;
		else
			precedent.setSuiv(nouveau);
		return L;
	}

	public static void main(String[] args) {
		Element listC = null;
		BufferedReader br = null;
		FileReader fr = null;
		try {
			fr = new FileReader("test.txt");
			br = new BufferedReader(fr);
			String sCurrentLine;
			while ((sCurrentLine = br.readLine()) != null)
				listC = insere(Integer.parseInt(sCurrentLine), listC);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
				if (fr != null)
					fr.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		System.out.println("Contenu de la liste :");
		while (listC != null) {
			System.out.println(listC.getInfo());
			listC = listC.getSuiv();
		}
	}
}
